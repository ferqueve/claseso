/* kernel.c */
#include "video.h"
#include "proceso.h"
#include "semaforo.h"
#include "kmalloc.h"
#include "fs.h"
#include "idt.h"
#include "pic.h"
#include "keyboard.h"

static semaforo_t mutex_contador;
static volatile int contador_compartido = 0;

/* proceso "A": incrementa el contador compartido protegido por semáforo,
   y va imprimiendo su letra en pantalla mientras corre. */
static void proceso_a(void) {
    for (int i = 0; i < 5; i++) {
        sem_wait(&mutex_contador);
        contador_compartido++;
        sem_signal(&mutex_contador);

        vga_print_char('A', 5, i, 0x0a);
        proceso_yield();
    }
    procesos[0].estado = TERMINADO;
    while (1) { proceso_yield(); }
}

/* proceso "B": lo mismo que A, para mostrar que ambos cooperan sin pisarse */
static void proceso_b(void) {
    for (int i = 0; i < 5; i++) {
        sem_wait(&mutex_contador);
        contador_compartido++;
        sem_signal(&mutex_contador);

        vga_print_char('B', 6, i, 0x0e);
        proceso_yield();
    }
    procesos[1].estado = TERMINADO;
    while (1) { proceso_yield(); }
}

void kmain(void) {
    vga_print("Hello from C kernel!", 0, 0x0f);

    /* --- demo: memoria dinámica (Clase 7) --- */
    char *saludo = (char*) kmalloc(32);
    saludo[0] = 'O'; saludo[1] = 'K'; saludo[2] = 0;
    vga_print(saludo, 1, 0x0b);
    kfree(saludo);

    /* --- demo: sistema de archivos (Clase 8) --- */
    int inodo = fs_crear("hola.txt");
    unsigned char contenido[] = "Hola FS";
    fs_escribir(inodo, contenido, 7);

    unsigned char leido[16];
    unsigned int n = fs_leer(inodo, leido);
    leido[n] = 0;
    vga_print((char*)leido, 2, 0x0c);

    /* --- demo: teclado por interrupciones (Clase 10) --- */
    pic_remapear();
    idt_instalar();
    teclado_instalar();
    asm volatile ("sti"); /* habilitar interrupciones — recién ahora el PIC puede avisarnos */

    vga_print("Escribi algo: ", 3, 0x0f);
    int columna = 0;
    while (columna < 20) {
        if (teclado_hay_dato()) {
            char c = teclado_leer();
            if (c == '\n') break;
            vga_print_char(c, 3, 14 + columna, 0x0d);
            columna++;
        }
    }

    /* --- demo: procesos + scheduler + semáforo (Clases 5 y 6) --- */
    sem_init(&mutex_contador, 1);
    crear_proceso(proceso_a);
    crear_proceso(proceso_b);

    procesos[0].estado = CORRIENDO;
    proceso_actual = 0;

    /* le entregamos la CPU al proceso 0 — kmain no vuelve a ejecutarse
       desde acá: el control queda cooperando entre proceso_a y proceso_b */
    contexto_t contexto_kmain;
    cambiar_contexto(&contexto_kmain, &procesos[0].ctx);

    while (1) { }
}
