/* fs.h */
#ifndef FS_H
#define FS_H

#define TAM_BLOQUE 512
#define NUM_BLOQUES 256
#define MAX_ARCHIVOS 16
#define BLOQUES_POR_ARCHIVO 4

typedef struct {
    char nombre[32];
    int ocupado;               /* 0 = libre, 1 = en uso */
    unsigned int tamano;       /* bytes usados */
    int bloques[BLOQUES_POR_ARCHIVO]; /* índices en disco_ram */
} inodo_t;

int fs_crear(const char *nombre);
int fs_escribir(int inodo, const unsigned char *datos, unsigned int tamano);
unsigned int fs_leer(int inodo, unsigned char *destino);

/*
 * NOTA: fs_borrar() queda como ejercicio del entregable (Parte B1) —
 * no está resuelta acá a propósito.
 */

#endif
