/* pic.h */
#ifndef PIC_H
#define PIC_H

void pic_remapear(void);
void pic_enviar_eoi(int irq);
void pic_desenmascarar_irq(int irq);

#endif
