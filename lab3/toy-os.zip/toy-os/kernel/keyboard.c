/* keyboard.c — driver de teclado por interrupciones (IRQ1) */
#include "io.h"
#include "idt.h"
#include "pic.h"
#include "keyboard.h"

#define PUERTO_TECLADO      0x60
#define TAM_BUFFER_TECLADO  64

static char buffer_teclado[TAM_BUFFER_TECLADO];
static int  buf_inicio = 0;
static int  buf_fin    = 0;

/* tabla minima scancode (set 1) -> ASCII; alcanza para la demo de
   la clase. Las posiciones en 0 son teclas que no traducimos hoy
   (shift, ctrl, F1-F12, flechas, etc.) */
static const char tabla_scancode[128] = {
    0,  27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, 'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, '\\','z','x','c','v','b','n','m',',','.','/', 0,
    '*', 0, ' '
    /* el resto del arreglo queda inicializado en 0 automaticamente */
};

static void buffer_push(char c) {
    int siguiente = (buf_fin + 1) % TAM_BUFFER_TECLADO;
    if (siguiente == buf_inicio) return; /* buffer lleno: se descarta */
    buffer_teclado[buf_fin] = c;
    buf_fin = siguiente;
}

int teclado_hay_dato(void) {
    return buf_inicio != buf_fin;
}

char teclado_leer(void) {
    if (buf_inicio == buf_fin) return 0;
    char c = buffer_teclado[buf_inicio];
    buf_inicio = (buf_inicio + 1) % TAM_BUFFER_TECLADO;
    return c;
}

/* GCC puede generar el prologo/epilogo (incluido el "iret" final) de
   un manejador de interrupcion automaticamente si lo marcamos con
   __attribute__((interrupt)) — evita escribir el stub en ensamblador
   a mano para cada interrupcion. */
void __attribute__((interrupt)) irq1_teclado(void *frame) {
    (void) frame;

    unsigned char scancode = inb(PUERTO_TECLADO);

    /* bit 7 en 1 = "tecla soltada" (break code) — las ignoramos */
    if (!(scancode & 0x80)) {
        char c = tabla_scancode[(unsigned char) scancode];
        if (c != 0) buffer_push(c);
    }

    pic_enviar_eoi(1);
}

void teclado_instalar(void) {
    idt_set_gate(0x21, (unsigned int) irq1_teclado); /* IRQ1 tras remapear = vector 33 (0x21) */
    pic_desenmascarar_irq(1);
}
