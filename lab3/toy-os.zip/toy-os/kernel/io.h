/* io.h - acceso a puertos de E/S (in/out) */
#ifndef IO_H
#define IO_H

static inline unsigned char inb(unsigned short puerto) {
    unsigned char valor;
    asm volatile ("inb %1, %0" : "=a"(valor) : "Nd"(puerto));
    return valor;
}

static inline void outb(unsigned short puerto, unsigned char valor) {
    asm volatile ("outb %0, %1" : : "a"(valor), "Nd"(puerto));
}

#endif
