/* semaforo.h */
#ifndef SEMAFORO_H
#define SEMAFORO_H

typedef struct {
    int valor;
} semaforo_t;

void sem_init(semaforo_t *s, int valor_inicial);
void sem_wait(semaforo_t *s);
void sem_signal(semaforo_t *s);

#endif
