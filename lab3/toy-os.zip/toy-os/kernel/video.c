/* video.c */
#include "video.h"

#define VIDEO_MEM ((unsigned char*) 0xb8000)
#define COLUMNAS 80

void vga_print_char(char c, int fila, int columna, unsigned char color) {
    int offset = (fila * COLUMNAS + columna) * 2;
    VIDEO_MEM[offset]     = c;
    VIDEO_MEM[offset + 1] = color;
}

void vga_print(const char *mensaje, int fila, unsigned char color) {
    int i = 0;
    while (mensaje[i] != 0) {
        vga_print_char(mensaje[i], fila, i, color);
        i++;
    }
}
