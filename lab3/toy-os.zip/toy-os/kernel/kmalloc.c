/* kmalloc.c */
#include "kmalloc.h"

/* _kernel_end la define linker.ld — justo después del binario del kernel */
extern unsigned char _kernel_end;

typedef struct bloque {
    unsigned int tamano;
    int libre;
    struct bloque *siguiente;
} bloque_t;

static unsigned char *heap_actual = 0;
static bloque_t *lista_bloques = 0;

static void heap_init_si_hace_falta(void) {
    if (heap_actual == 0) {
        heap_actual = &_kernel_end;
    }
}

void* kmalloc(unsigned int tamano) {
    heap_init_si_hace_falta();

    bloque_t *actual = lista_bloques;

    /* 1. buscar un bloque libre que alcance */
    while (actual != 0) {
        if (actual->libre && actual->tamano >= tamano) {
            actual->libre = 0;
            return (void*)(actual + 1);
        }
        actual = actual->siguiente;
    }

    /* 2. si no hay ninguno, pedir memoria nueva */
    bloque_t *nuevo = (bloque_t*) heap_actual;
    heap_actual += sizeof(bloque_t) + tamano;

    nuevo->tamano = tamano;
    nuevo->libre = 0;
    nuevo->siguiente = lista_bloques;
    lista_bloques = nuevo;

    return (void*)(nuevo + 1);
}

void kfree(void *ptr) {
    if (ptr == 0) return;
    bloque_t *b = ((bloque_t*)ptr) - 1;
    b->libre = 1;
}
