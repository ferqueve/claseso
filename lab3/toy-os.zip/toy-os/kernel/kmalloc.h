/* kmalloc.h */
#ifndef KMALLOC_H
#define KMALLOC_H

void* kmalloc(unsigned int tamano);
void  kfree(void *ptr);

#endif
