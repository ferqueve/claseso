[org 0x7c00]
[bits 16]

; el BIOS nos pasa el número de unidad de arranque en DL — lo guardamos
; antes de que alguna otra instrucción lo pise
mov [BOOT_DRIVE], dl

; mensaje de bienvenida (Clase 3)
mov si, mensaje_bienvenida
call imprimir_string

; cargar el resto del kernel del disco (todavía en modo real)
mov bx, KERNEL_OFFSET
mov dh, 15                 ; cantidad de sectores a leer (ajustar al tamaño real de kernel.bin)
mov dl, [BOOT_DRIVE]
call leer_disco

; configurar la GDT y pasar a modo protegido
cli
lgdt [gdt_descriptor]
mov eax, cr0
or eax, 1
mov cr0, eax
jmp CODE_SEG:init_pm

; ------------------------------------------------------------------
; subrutinas de modo real
; ------------------------------------------------------------------

imprimir_string:
    lodsb
    cmp al, 0
    je .listo
    mov ah, 0x0e
    int 0x10
    jmp imprimir_string
.listo:
    ret

leer_disco:
    mov ah, 0x02      ; función BIOS: leer sectores
    mov al, dh        ; cantidad de sectores a leer (la pusimos en dh al llamar)
    mov ch, 0x00      ; cilindro 0
    mov cl, 0x02      ; empezar en el sector 2 (el sector 1 es el bootloader)
    mov dh, 0x00      ; cabeza 0
    int 0x13
    jc disco_error
    ret

disco_error:
    mov si, mensaje_error
    call imprimir_string
    jmp $

; ------------------------------------------------------------------
; datos
; ------------------------------------------------------------------
KERNEL_OFFSET equ 0x1000
BOOT_DRIVE:         db 0
mensaje_bienvenida: db 'Hello, Toy OS!', 0
mensaje_error:      db 'Error al leer disco', 0

; ------------------------------------------------------------------
; GDT
; ------------------------------------------------------------------
gdt_start:
    dq 0

gdt_code:
    dw 0xffff, 0
    db 0, 10011010b, 11001111b, 0

gdt_data:
    dw 0xffff, 0
    db 0, 10010010b, 11001111b, 0
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

; ------------------------------------------------------------------
; modo protegido (32 bits)
; ------------------------------------------------------------------
[bits 32]
init_pm:
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    call KERNEL_OFFSET

; relleno hasta 510 bytes + firma de arranque
times 510-($-$$) db 0
dw 0xaa55
