/* proceso.h */
#ifndef PROCESO_H
#define PROCESO_H

#define MAX_PROCESOS 4
#define TAM_PILA 4096

enum estado_proceso { NUEVO, LISTO, CORRIENDO, BLOQUEADO, TERMINADO };

typedef struct {
    unsigned int esp;   /* stack pointer guardado */
} contexto_t;

typedef struct {
    int id;
    enum estado_proceso estado;
    contexto_t ctx;
    unsigned char pila[TAM_PILA];  /* stack propio de 4 KB */
} proceso_t;

extern proceso_t procesos[MAX_PROCESOS];
extern int num_procesos;
extern int proceso_actual;

int  crear_proceso(void (*funcion)(void));
void cambiar_contexto(contexto_t *viejo, contexto_t *nuevo);
void planificador(void);
void proceso_yield(void);

#endif
