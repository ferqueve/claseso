/* scheduler.c */
#include "proceso.h"

proceso_t procesos[MAX_PROCESOS];
int num_procesos = 0;
int proceso_actual = 0;

/*
 * Al crear un proceso dejamos "preparada" su pila para que, la primera vez
 * que se le entregue la CPU, cambiar_contexto pueda hacer popad + ret y
 * terminar saltando directo a su función.
 *
 * Layout que construimos (de la dirección más alta a la más baja, que es
 * el orden en que "pushad" real los habría dejado):
 *   [más alto]  dirección de retorno = funcion   <- lo consume "ret"
 *               EAX (dummy)
 *               ECX (dummy)
 *               EDX (dummy)
 *               EBX (dummy)
 *               ESP original (dummy, popad lo descarta sin usarlo)
 *               EBP (dummy)
 *               ESI (dummy)
 *   [más bajo]  EDI (dummy)  <- acá queda el nuevo esp inicial
 */
int crear_proceso(void (*funcion)(void)) {
    if (num_procesos >= MAX_PROCESOS) return -1;

    proceso_t *p = &procesos[num_procesos];
    p->id = num_procesos;
    p->estado = LISTO;

    unsigned int *tope = (unsigned int*)(p->pila + TAM_PILA);

    *(--tope) = (unsigned int) funcion; /* dirección de retorno para "ret" */
    *(--tope) = 0; /* EAX */
    *(--tope) = 0; /* ECX */
    *(--tope) = 0; /* EDX */
    *(--tope) = 0; /* EBX */
    *(--tope) = 0; /* ESP original (ignorado por popad) */
    *(--tope) = 0; /* EBP */
    *(--tope) = 0; /* ESI */
    *(--tope) = 0; /* EDI */

    p->ctx.esp = (unsigned int) tope;

    num_procesos++;
    return p->id;
}

/*
 * cambiar_contexto() está implementada en switch.asm (no en C).
 *
 * Motivo técnico: si la escribiéramos con asm inline dentro de una función
 * de C (como se muestra de forma simplificada en la Clase 5/6 para explicar
 * la idea), el propio epílogo que GCC genera para la función -que restaura
 * esp a partir de ebp- deshace nuestro cambio manual de esp apenas termina
 * el bloque de asm inline. Escribirla en ensamblador puro evita ese problema
 * y es, en la práctica, cómo se implementa un cambio de contexto real.
 */

void planificador(void) {
    if (num_procesos == 0) return;

    int anterior = proceso_actual;
    int siguiente = (proceso_actual + 1) % num_procesos;

    while (procesos[siguiente].estado != LISTO && siguiente != anterior) {
        siguiente = (siguiente + 1) % num_procesos;
    }
    if (procesos[siguiente].estado != LISTO) return; /* nadie más listo */

    procesos[anterior].estado = LISTO;
    procesos[siguiente].estado = CORRIENDO;
    proceso_actual = siguiente;

    cambiar_contexto(&procesos[anterior].ctx, &procesos[siguiente].ctx);
}

void proceso_yield(void) {
    planificador();
}
