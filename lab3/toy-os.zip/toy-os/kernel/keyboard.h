/* keyboard.h */
#ifndef KEYBOARD_H
#define KEYBOARD_H

void teclado_instalar(void);
int  teclado_hay_dato(void);
char teclado_leer(void);

#endif
