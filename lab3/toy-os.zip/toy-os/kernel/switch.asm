; switch.asm
;
; void cambiar_contexto(contexto_t *viejo, contexto_t *nuevo);
;
; contexto_t es { unsigned int esp; } — cada puntero apunta directo al
; entero que guarda el stack pointer.
;
; IMPORTANTE: además de cambiar esp, hay que preservar los registros de
; propósito general (EBX, ESI, EDI, EBP son "callee-saved" en cdecl: el
; código que llama a esta función asume que se preservan a través de la
; llamada). Si solo intercambiáramos esp sin pushad/popad, el compilador
; podría estar usando esos registros para variables locales (por ejemplo,
; el contador de un for) y State del proceso saliente contaminaría al
; proceso entrante — un bug real y difícil de ver a simple vista.
;
; Se escribe en ensamblador puro (no como asm inline dentro de una función
; de C) para evitar que el epílogo que GCC genera automáticamente
; (mov esp, ebp / pop ebp) deshaga nuestro cambio manual de esp.

[bits 32]
global cambiar_contexto

cambiar_contexto:
    mov eax, [esp+4]      ; argumento 1: puntero a contexto viejo
    mov edx, [esp+8]      ; argumento 2: puntero a contexto nuevo

    pushad                ; guardar TODOS los registros del proceso saliente
    mov [eax], esp        ; contexto_viejo->esp = esp (justo después de pushad)

    mov esp, [edx]        ; cargar el esp guardado del proceso entrante
    popad                 ; restaurar sus registros
    ret                    ; saltar a la dirección de retorno de su propia pila
