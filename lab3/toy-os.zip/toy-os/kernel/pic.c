/* pic.c — remapeo del controlador de interrupciones 8259 (PIC) */
#include "io.h"
#include "pic.h"

#define PIC1_COMANDO 0x20
#define PIC1_DATOS   0x21
#define PIC2_COMANDO 0xA0
#define PIC2_DATOS   0xA1

/* Por defecto el PIC manda las IRQ 0-15 a los vectores de interrupcion
   8-15 y 0x70-0x77 — que la CPU x86 ya usa para sus propias excepciones
   (0-31). Sin remapear, un IRQ de teclado se confundiria con una
   excepcion de CPU. Lo movemos a partir del vector 32 (0x20), que
   esta libre. */
void pic_remapear(void) {
    outb(PIC1_COMANDO, 0x11); /* ICW1: iniciar secuencia de configuracion */
    outb(PIC2_COMANDO, 0x11);

    outb(PIC1_DATOS, 0x20);   /* ICW2: IRQ 0-7  -> interrupciones 32-39 */
    outb(PIC2_DATOS, 0x28);   /* ICW2: IRQ 8-15 -> interrupciones 40-47 */

    outb(PIC1_DATOS, 0x04);   /* ICW3: hay un PIC esclavo colgado de IRQ2 */
    outb(PIC2_DATOS, 0x02);

    outb(PIC1_DATOS, 0x01);   /* ICW4: modo 8086 */
    outb(PIC2_DATOS, 0x01);

    /* IMPORTANTE: enmascaramos TODAS las IRQ acá. El PIC trae el
       temporizador (IRQ0) desenmascarado de fabrica — si lo dejamos
       asi y no instalamos un manejador para su vector, la primera
       interrupcion de timer que llegue encuentra una entrada vacia
       en la IDT y termina en un triple fault (¡lo vimos pasar!).
       Cada driver que instalemos (como el de teclado) desenmascara
       PUNTUALMENTE la IRQ que sabe atender. */
    outb(PIC1_DATOS, 0xFF);
    outb(PIC2_DATOS, 0xFF);
}

/* hay que avisarle al PIC "ya la atendi" (End Of Interrupt), o no
   vuelve a mandar mas interrupciones de ningun tipo */
void pic_enviar_eoi(int irq) {
    if (irq >= 8) outb(PIC2_COMANDO, 0x20);
    outb(PIC1_COMANDO, 0x20);
}

void pic_desenmascarar_irq(int irq) {
    unsigned short puerto = (irq < 8) ? PIC1_DATOS : PIC2_DATOS;
    unsigned char  bit    = (irq < 8) ? irq : (irq - 8);
    unsigned char  valor  = inb(puerto) & ~(1 << bit);
    outb(puerto, valor);
}
