/* semaforo.c */
#include "semaforo.h"
#include "proceso.h"

void sem_init(semaforo_t *s, int valor_inicial) {
    s->valor = valor_inicial;
}

void sem_wait(semaforo_t *s) {
    while (s->valor <= 0) {
        proceso_yield();  /* cede la CPU mientras espera */
    }
    s->valor--;
}

void sem_signal(semaforo_t *s) {
    s->valor++;
}
