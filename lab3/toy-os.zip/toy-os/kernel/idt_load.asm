; idt_load.asm
; void idt_cargar(unsigned int idt_ptr_addr);
[bits 32]
global idt_cargar

idt_cargar:
    mov eax, [esp+4]
    lidt [eax]
    ret
