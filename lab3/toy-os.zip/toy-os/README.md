# toy-os — Sistema Operativos de Juguete

Proyecto base **completo y verificado** del kernel de juguete, integrando el
código de las Clases 3 a 10. No son fragmentos: cada archivo compila, linkea
y corre de verdad en QEMU.

## Qué incluye

| Archivo | De qué clase | Qué hace |
|---|---|---|
| `boot/boot.asm` | Clase 3 y 4 | Bootloader: imprime mensaje, lee el kernel del disco, arma la GDT y salta a modo protegido |
| `boot/kernel_entry.asm` | Clase 4 | Stub de 32 bits: lo primero que corre, llama a `kmain()` |
| `kernel/video.c` / `video.h` | Clase 4 | Escribir texto directo en la memoria de video (`0xb8000`) |
| `kernel/proceso.h` | Clase 5 | El PCB (`proceso_t`), estados y prototipos del scheduler |
| `kernel/scheduler.c` | Clase 5 | `crear_proceso()`, `planificador()` round-robin cooperativo |
| `kernel/switch.asm` | Clase 5 | Cambio de contexto real (`pushad`/`popad`/`ret`) |
| `kernel/semaforo.c` / `semaforo.h` | Clase 6 | `sem_init/wait/signal` — exclusión mutua |
| `kernel/kmalloc.c` / `kmalloc.h` | Clase 7 | Allocator con free-list — `kmalloc()`/`kfree()` |
| `kernel/fs.c` / `fs.h` | Clase 8 | "Disco" simulado en RAM + `fs_crear/escribir/leer` |
| `kernel/io.h` | Clase 10 | `inb`/`outb` — acceso a puertos de E/S |
| `kernel/idt.c` / `idt.h` / `idt_load.asm` | Clase 10 | Tabla de Descriptores de Interrupción (IDT) |
| `kernel/pic.c` / `pic.h` | Clase 10 | Remapeo del PIC 8259 (IRQ 0-15 → vectores 32-47) |
| `kernel/keyboard.c` / `keyboard.h` | Clase 10 | Driver de teclado por interrupciones (IRQ1) |
| `kernel/kernel.c` | — | `kmain()`: orquesta una demo de todo lo anterior |
| `linker.ld` | Clase 4 | Ubica el kernel en `0x1000` y define `_kernel_end` |
| `Makefile` | Clase 3-10 | Automatiza todo el proceso de compilación |

## Cómo compilar y correr

Dentro de la VM Ubuntu, con el toolchain de la Clase 3 instalado
(`nasm`, `gcc`, `ld`, `qemu-system-x86`):

```bash
make        # compila todo y genera os-image.bin
make run    # lo corre en QEMU
```

Deberías ver en pantalla:

```
Hello from C kernel!
OK
Hola FS
Escribi algo: <lo que tipees>
```

Y más abajo, dos filas que se van completando con letras `A` y `B`
alternadas (el resultado de dos procesos cooperando vía el scheduler y un
semáforo protegiendo un contador compartido).

## Dos bugs reales que encontramos y corregimos

**1. Cambio de contexto sin preservar registros (Clase 5/6).**
La primera versión de `switch.asm` solo intercambiaba `esp` sin preservar
los demás registros (`pushad`/`popad`). Como el compilador asume que
`ebx`/`esi`/`edi`/`ebp` se preservan a través de cualquier llamada a
función (son "callee-saved" en la convención cdecl), el proceso `B`
terminaba corriendo sus 5 iteraciones seguidas mientras `A` se quedaba
en una sola — sin preservar registros, la variable del `for` de un
proceso se mezclaba con la del otro. Se corrigió agregando `pushad`/
`popad` en el cambio de contexto, y ajustando `crear_proceso()` para
dejar la pila inicial de cada proceso con los 8 registros dummy que
`popad` espera encontrar.

**2. Triple fault al habilitar interrupciones (Clase 10).**
Al remapear el PIC 8259, el temporizador (IRQ0) queda desenmascarado
por defecto. Como no instalamos ningún manejador para su vector en la
IDT, la primera interrupción de timer que llegaba encontraba una
entrada vacía → excepción sin manejador → double fault → triple fault
→ QEMU reiniciaba la CPU (con `-no-reboot`, directamente se cerraba).
Se corrigió enmascarando TODAS las IRQ en `pic_remapear()`, y dejando
que cada driver (como `teclado_instalar()`) desenmascare puntualmente
solo la IRQ que sabe atender.

Vale la pena comentar ambos en clase: son exactamente el tipo de bug
sutil que aparece al escribir un kernel real, y por qué probamos todo
en QEMU antes de dar el código por bueno.

## Extensiones propuestas (ver el entregable)

- `fs_borrar()` — liberar un archivo (Parte B1 del entregable)
- Lectores-escritores con semáforos (Parte B2)
- Prioridades en el scheduler (Parte B3)
- Proteger `kmalloc`/`kfree` con un semáforo (Parte B4, bonus)
