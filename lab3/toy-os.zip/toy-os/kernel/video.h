/* video.h */
#ifndef VIDEO_H
#define VIDEO_H

void vga_print(const char *mensaje, int fila, unsigned char color);
void vga_print_char(char c, int fila, int columna, unsigned char color);

#endif
