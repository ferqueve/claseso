/* fs.c */
#include "fs.h"

static unsigned char disco_ram[NUM_BLOQUES][TAM_BLOQUE];
static int bitmap_bloques[NUM_BLOQUES]; /* 0 = libre, 1 = ocupado */
static inodo_t tabla_inodos[MAX_ARCHIVOS];

static int buscar_bloque_libre(void) {
    for (int i = 0; i < NUM_BLOQUES; i++) {
        if (bitmap_bloques[i] == 0) return i;
    }
    return -1; /* disco lleno */
}

int fs_crear(const char *nombre) {
    for (int i = 0; i < MAX_ARCHIVOS; i++) {
        if (!tabla_inodos[i].ocupado) {
            int j = 0;
            while (nombre[j] != 0 && j < 31) {
                tabla_inodos[i].nombre[j] = nombre[j];
                j++;
            }
            tabla_inodos[i].nombre[j] = 0;
            tabla_inodos[i].ocupado = 1;
            tabla_inodos[i].tamano = 0;
            return i; /* número de inodo asignado */
        }
    }
    return -1; /* no hay inodos libres */
}

int fs_escribir(int inodo, const unsigned char *datos, unsigned int tamano) {
    if (inodo < 0 || inodo >= MAX_ARCHIVOS || !tabla_inodos[inodo].ocupado) return -1;

    int bloque = buscar_bloque_libre();
    if (bloque == -1) return -1; /* sin espacio */

    for (unsigned int i = 0; i < tamano && i < TAM_BLOQUE; i++) {
        disco_ram[bloque][i] = datos[i];
    }

    bitmap_bloques[bloque] = 1;
    tabla_inodos[inodo].bloques[0] = bloque;
    tabla_inodos[inodo].tamano = tamano;
    return 0;
}

unsigned int fs_leer(int inodo, unsigned char *destino) {
    if (inodo < 0 || inodo >= MAX_ARCHIVOS || !tabla_inodos[inodo].ocupado) return 0;

    int bloque = tabla_inodos[inodo].bloques[0];
    unsigned int tamano = tabla_inodos[inodo].tamano;

    for (unsigned int i = 0; i < tamano; i++) {
        destino[i] = disco_ram[bloque][i];
    }
    return tamano;
}
