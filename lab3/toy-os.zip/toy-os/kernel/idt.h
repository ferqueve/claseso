/* idt.h */
#ifndef IDT_H
#define IDT_H

void idt_set_gate(int n, unsigned int handler);
void idt_instalar(void);

#endif
