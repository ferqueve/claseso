; kernel_entry.asm
; Lo primero que se ejecuta al llegar a KERNEL_OFFSET desde boot.asm.
; Simplemente llama a kmain() (escrita en C) y, si alguna vez retorna,
; se queda en un bucle infinito (un kernel no tiene "a dónde volver").

[bits 32]
global _start
extern kmain

_start:
    call kmain
    jmp $
