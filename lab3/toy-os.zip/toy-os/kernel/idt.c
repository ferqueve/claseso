/* idt.c — Tabla de Descriptores de Interrupcion (IDT) */
#include "idt.h"

#define NUM_ENTRADAS_IDT 256

typedef struct __attribute__((packed)) {
    unsigned short offset_bajo;
    unsigned short selector;
    unsigned char  cero;
    unsigned char  tipo_attr;
    unsigned short offset_alto;
} idt_entry_t;

typedef struct __attribute__((packed)) {
    unsigned short limite;
    unsigned int   base;
} idt_ptr_t;

static idt_entry_t idt[NUM_ENTRADAS_IDT];
static idt_ptr_t   idt_ptr;

extern void idt_cargar(unsigned int idt_ptr_addr);

void idt_set_gate(int n, unsigned int handler) {
    idt[n].offset_bajo = handler & 0xFFFF;
    idt[n].selector    = 0x08;  /* selector de codigo del kernel (GDT, Clase 4) */
    idt[n].cero        = 0;
    idt[n].tipo_attr   = 0x8E;  /* presente, anillo 0, gate de interrupcion de 32 bits */
    idt[n].offset_alto = (handler >> 16) & 0xFFFF;
}

void idt_instalar(void) {
    idt_ptr.limite = sizeof(idt) - 1;
    idt_ptr.base   = (unsigned int) &idt;
    idt_cargar((unsigned int) &idt_ptr);
}
